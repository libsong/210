/* Share the spi flash code */
#include "../bf537-stamp/spi_flash.c"

/* parallel not implemented yet */

extern int cma_parallel_not_implemented;
